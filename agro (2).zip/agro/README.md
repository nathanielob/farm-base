# My-Agro
We can automate our agricultural work in easy way and we can sell,buy and bid an agricultural productfrom our place.We get lot of suggestions,tips and techniques and  about agriculture,finance and its scheme.
# Our team
We are a group of students tries to reduce formers suicide and increasing their profit.
our team consists of 4 members
**Sathyaseelan.S,Maheshwaran.G,A.S.Gowtham kumar and Siva prakash.M**
# How to test this application
Its so easy to test this application.All you need is server.it may be localhost or any server
* Download and install WAMP server and copy all the files to WWW directory.
* Open phpmyadmin in localhost and create database with name of myagro
* Then import SQL file into database.
* Open localhost and navigate to our app by giving url in address bar URL: http://localhost/myagro
# Our wish
We feel very hapy to participate in this contest.
Thank you.
