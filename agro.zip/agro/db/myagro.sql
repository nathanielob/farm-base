-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2017 at 10:35 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myagro`
--

-- --------------------------------------------------------

--
-- Table structure for table `bid`
--

CREATE TABLE IF NOT EXISTS `bid` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `proid` int(10) NOT NULL,
  `bidderid` int(10) NOT NULL,
  `price` int(100) NOT NULL,
  `posistion` varchar(100) NOT NULL DEFAULT 'NotSelected',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `bidproducts`
--

CREATE TABLE IF NOT EXISTS `bidproducts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `price` int(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `descr` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `postedby` int(100) NOT NULL,
  `img` varchar(100) NOT NULL,
  `verified` varchar(10) NOT NULL DEFAULT 'no',
  `completed` varchar(100) NOT NULL DEFAULT '0',
  `winnerId` int(10) NOT NULL DEFAULT '0',
  `username` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bidproducts`
--

INSERT INTO `bidproducts` (`id`, `price`, `quantity`, `descr`, `name`, `dateadded`, `postedby`, `img`, `verified`, `completed`, `winnerId`, `username`) VALUES
(5, 1, '10', 'onaapo', 'sobolo', '2017-04-18 16:23:18', 12, 'img/486687533.jpg', 'no', '0', 0, 'Natty');

-- --------------------------------------------------------

--
-- Table structure for table `finance`
--

CREATE TABLE IF NOT EXISTS `finance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `datedo` date NOT NULL,
  `postedby` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `finance`
--

INSERT INTO `finance` (`id`, `name`, `price`, `type`, `datedo`, `postedby`) VALUES
(3, ' cassava', 50, 'sell', '0000-00-00', 13),
(4, 'coconut', 30, 'buy', '0000-00-00', 13),
(5, 'coconut', 30, 'buy', '0000-00-00', 13);

-- --------------------------------------------------------

--
-- Table structure for table `follow`
--

CREATE TABLE IF NOT EXISTS `follow` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `follower` int(10) NOT NULL,
  `followedby` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `follow`
--

INSERT INTO `follow` (`id`, `follower`, `followedby`) VALUES
(5, 16, 13),
(6, 13, 16);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `nid` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL,
  `msg` varchar(100) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`nid`, `id`, `msg`) VALUES
(25, 16, 'lord followed you'),
(26, 13, 'miller followed you');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE IF NOT EXISTS `price` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CROP` varchar(20) NOT NULL,
  `QUANT` varchar(30) NOT NULL,
  `MARKET` varchar(150) NOT NULL,
  `PRICE` varchar(120) DEFAULT NULL,
  `dateadded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`ID`, `CROP`, `QUANT`, `MARKET`, `PRICE`, `dateadded`) VALUES
(1, 'Cocoyam', 'Tuber', 'Kasoa', '12', '2017-04-09 15:55:12'),
(2, 'Plantain', 'Tuber', 'Kaneshie', '12', '2017-04-28 15:55:12'),
(3, 'Plantain', 'Fingers', 'Madina', '120', '2017-04-28 15:55:12'),
(4, 'Cassava', 'Tuber', 'Kasoa', '50', '2017-04-28 15:55:12'),
(5, 'Cassava', 'Tuber', 'Kaneshie', '17', '2017-04-28 15:55:12'),
(6, 'Cassava', 'Tuber', 'Madina', '12', '2017-04-28 16:19:40'),
(7, 'Cassava', 'Tuber', 'Kaneshie', '2', '2017-04-30 15:40:29');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `descr` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `subcategory` varchar(100) NOT NULL,
  `dateadded` date NOT NULL,
  `img` varchar(100) NOT NULL,
  `userid` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `descr`, `price`, `unit`, `subcategory`, `dateadded`, `img`, `userid`) VALUES
(20, 'sobolo', 'onaapo', 2, '5', 'drinks', '2017-04-18', 'img/1654646710.jpg', 12);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `addr1` varchar(100) NOT NULL,
  `addr2` varchar(100) NOT NULL,
  `dist` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin` int(100) NOT NULL,
  `profilepic` varchar(100) NOT NULL DEFAULT 'img\\profilepic\\img.png',
  `acres` int(100) NOT NULL,
  `cul` int(100) NOT NULL,
  `amt` int(100) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `uid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `fname`, `lname`, `addr1`, `addr2`, `dist`, `state`, `pin`, `profilepic`, `acres`, `cul`, `amt`, `startdate`, `enddate`, `uid`) VALUES
(10, '', '', '', '', '', '', 0, 'img\\profilepic\\img.png', 0, 0, 0, '0000-00-00', '0000-00-00', 12),
(11, '', '', '', '', '', '', 0, 'img\\profilepic\\img.png', 0, 0, 0, '0000-00-00', '0000-00-00', 0),
(12, 'LORD', 'MOPO', '0987', '1243', 'KNUST', 'KUMASI', 123, 'img/profilepic/13.jpg', 10, 2, 400, '2017-03-04', '2017-08-09', 13),
(13, '', '', '', '', '', '', 0, 'img\\profilepic\\img.png', 0, 0, 0, '0000-00-00', '0000-00-00', 14),
(14, '', '', '', '', '', '', 0, 'img\\profilepic\\img.png', 0, 0, 0, '0000-00-00', '0000-00-00', 15),
(15, 'MILLER', 'OBENG', '1234', '5678', 'VVU', 'ACCRA', 100, 'img/profilepic/16.png', 5, 3, 1000, '2017-02-20', '2017-07-20', 16),
(16, '', '', '', '', '', '', 0, 'img\\profilepic\\img.png', 0, 0, 0, '0000-00-00', '0000-00-00', 17);

-- --------------------------------------------------------

--
-- Table structure for table `publicchat`
--

CREATE TABLE IF NOT EXISTS `publicchat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL,
  `msg` varchar(100) NOT NULL,
  `dandt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `publicchat`
--

INSERT INTO `publicchat` (`id`, `sid`, `msg`, `dandt`) VALUES
(12, 13, 'hi', '2017-04-22 19:50:37'),
(13, 16, 'whats up', '2017-04-23 01:34:40'),
(14, 13, 'yh you tell me', '2017-04-23 01:34:56'),
(15, 16, 'nothing much', '2017-04-23 01:35:08');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pno` varchar(100) NOT NULL,
  `datecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pass` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `uname`, `email`, `pno`, `datecreated`, `pass`, `occupation`) VALUES
(12, 'natty', 'natty@gmail.com', '1234567898', '2017-04-18 16:15:05', 'oprime', 'Farmer'),
(13, 'lord', 'lord@gmail.com', '987654321', '2017-04-22 19:43:14', 'lord', 'Farmer'),
(14, 'bentil', 'bentil@gmail.com', '987654322', '2017-04-22 20:31:23', 'bentil', 'Industrialists'),
(15, 'abel', 'abel@gmail.com', '567348290', '2017-04-22 20:34:21', 'abel', 'Dealer'),
(16, 'miller', 'miller@gmail.com', '987123456', '2017-04-23 01:09:51', 'miller', 'Farmer'),
(17, 'nana', 'nana@gmail.com', '9787334343', '2017-04-28 15:27:08', 'nana', 'Farmer');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
